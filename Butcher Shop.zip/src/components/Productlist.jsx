import "../styles/productos.css";
import { Link } from "react-router-dom";

import { useProductList } from "../hooks/useProductList";
import { Pagination } from "./Pagination";

function Productlist() {
  const {
    products,
    filteredProducts,
    productsPerPage,
    currentPage,
    searchTerm,
    handleFilter,
    handleSearch,
    firstIndex,
    lastIndex,
    totalProducts,
    setCurrentPage,
  } = useProductList();

  return (
    <>
      <section class="sectiontitle">
        <div className="container-title">
          <h1 className="title is-3 has-text-white has-text-right newh1">
            Productos
          </h1>
        </div>
      </section>
      <section className="section section-products">
        <div className="container">
          <div className="columns">
            <div className="column is-8">
              <div className="field">
                <div className="control container-filtro">
                  <label className="label-text">Filtrar por Categoria:</label>
                  <div className="select">
                    <select onChange={(e) => handleFilter(e.target.value)}>
                      <option value="">Todos</option>
                      <option value="electronics">Electrónicos</option>
                      <option value="men's clothing">Ropa Masculina</option>
                      <option value="women's clothing">Ropa Femenina</option>
                      <option value="jewelery">Joyería</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div className="column">
              <div className="field container-search">
                <div className="control">
                  <input
                    type="text"
                    className="input is-info"
                    placeholder="Buscar..."
                    value={searchTerm}
                    onChange={(e) => handleSearch(e.target.value)}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="container-products">
            {filteredProducts
              .map((product) => (
                <div className="card-product" key={product.id}>
                  <Link to={`/productos/${product.id}`}>
                    <figure className="container-img">
                      <img src={product.image} alt={product.title} />
                    </figure>
                    <div className="info-product">
                      <h3>{product.title}</h3>
                      <p className="price">$ {product.price}</p>
                    </div>
                  </Link>
                </div>
              ))
              .slice(firstIndex, lastIndex)}
          </div>
          <Pagination
            productsPerPage={productsPerPage}
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            totalProducts={totalProducts}
          />
        </div>
      </section>
    </>
  );
}

export default Productlist;
