import { validateEmail, validatePassword } from "../hooks/useValidations";
import { useState } from "react";

const Login = () => {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const [errors, setErrors] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });

    if (name === "email") {
      const isValid = validateEmail(value);
      setErrors({
        ...errors,
        email: isValid ? "" : "Correo electrónico no válido.",
      });
    }

    if (name === "password") {
      const isValid = validatePassword(value);
      setErrors({
        ...errors,
        password: isValid ? "" : "La Contraseña no es válida.",
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const isEmailValid = validateEmail(formData.email);
    const isPasswordValid = validateEmail(formData.password);

    if (isEmailValid && isPasswordValid) {
    } else {
      setErrors({
        email: isEmailValid ? "" : "Correo electrónico no válido.",
        password: isPasswordValid ? "" : "Contraseña no es válida.",
      });
    }
  };

  return (
    <>
      <section class="sectiontitle">
        <div className="container-title">
          <h1 className="title is-3 has-text-white has-text-right newh1">
            Mi Cuenta
          </h1>
        </div>
      </section>
      <section class="section sectionlogin">
        <div class="container container-background">
          <div class="columns is-centered">
            <div class="column is-5 is-offset-8">
              <div class="box">
                <form onSubmit={handleSubmit}>
                  <div class="field">
                    <label class="label">Correo</label>
                    <div class="control">
                      <input
                        type="email"
                        id="email"
                        name="email"
                        class="input"
                        placeholder="correo@example.com"
                        onChange={handleChange}
                      />
                    </div>
                    {errors.email && (
                      <p className="help is-danger">{errors.email}</p>
                    )}
                  </div>
                  <div class="field">
                    <label class="label">Contraseña</label>
                    <div class="control">
                      <input
                        type="password"
                        id="password"
                        name="password"
                        class="input"
                        placeholder="Ingrese su contraseña"
                        onChange={handleChange}
                      />
                    </div>
                    {errors.password && (
                      <p className="help is-danger">{errors.password}</p>
                    )}
                  </div>
                  <div class="field is-grouped is-grouped-centered">
                    <div class="control">
                      <button
                        class="button is-danger button-login"
                        type="submit"
                      >
                        Inicar Sesión
                      </button>
                    </div>
                  </div>
                  <p class="subtitle is-6 has-text-centered mb-1 newsubtitle">
                    ¿No tiene cuenta?
                    <a class="signup" href="#">
                      Da click aquí.
                    </a>
                  </p>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Login;
