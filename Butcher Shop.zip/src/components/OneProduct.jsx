import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";
import { useProductList } from "../hooks/useProductList";

const OneProduct = () => {
  const { id } = useParams();
  const { products } = useProductList();

  const product = products.find((product) => product.id === parseInt(id));

  if (!product) {
    return null;
  }

  return (
    <section className="oneproduct">
      <div className="columns productopromo">
        <div className="column is-6 columnimagen">
          <div className="image-product">
            <div className="centered-image">
              <img src={product.image} alt="" className="is-4 product-image" />
            </div>
          </div>
        </div>
        <div className="column has-background-black columnpromo containerdescrip">
          <div className="container-promo has-text-centered">
            <h2 className="title is-1 newh2">{product.title}</h2>
            <p className="has-text-white">{product.description}</p>
            <div className="boton-productos">
              <Link to="">
                <p className="button is-outlined is-info btncomprar">
                  Comprar ahora
                </p>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default OneProduct;
