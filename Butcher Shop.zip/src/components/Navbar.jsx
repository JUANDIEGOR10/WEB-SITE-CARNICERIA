import React from "react";
import useNavbar from "../hooks/useSelectBurger";
import "../styles/style.css";
import { Link } from "react-router-dom";

function Navbar() {
  const { menuActive, selectedItem, toggleMenu, handleMenuItemClick } =
    useNavbar();

  return (
    <nav
      className={`navbar is-black`}
      role="navigation"
      aria-label="main navigation"
    >
      <div className="navbar-brand">
        <Link className="navbar-item" to="/">
          <img src="/src/img/Logo192x192.png" width={40} alt="Logo" />
        </Link>
        <Link className="navbar-item namepage" to="/">
          <strong>Butcher Shop</strong>
        </Link>
        <a
          role="button"
          className={`navbar-burger ${menuActive ? "is-active" : ""}`}
          aria-label="menu"
          aria-expanded={menuActive}
          onClick={toggleMenu}
        >
          <span aria-hidden="true"></span>
          <span aria-hidden="true"></span>
          <span aria-hidden="true"></span>
        </a>
      </div>
      <div className={`navbar-menu ${menuActive ? "is-active" : ""}`}>
        <div className="navbar-end">
          <Link
            className={`navbar-item ${
              selectedItem === "Inicio" ? "selected" : ""
            }`}
            to="/"
            onClick={() => handleMenuItemClick("Inicio")}
          >
            Inicio
          </Link>
          <Link
            className={`navbar-item ${
              selectedItem === "Nosotros" ? "selected" : ""
            }`}
            to="/nosotros"
            onClick={() => handleMenuItemClick("Nosotros")}
          >
            Nosotros
          </Link>
          <Link
            className={`navbar-item ${
              selectedItem === "Contacto" ? "selected" : ""
            }`}
            to="/contacto"
            onClick={() => handleMenuItemClick("Contacto")}
          >
            Contacto
          </Link>
          <Link
            className={`navbar-item ${
              selectedItem === "Productos" ? "selected" : ""
            }`}
            to="/productos"
            onClick={() => handleMenuItemClick("Productos")}
          >
            Productos
          </Link>
          <Link
            className={`navbar-item ${
              selectedItem === "Login" ? "selected" : ""
            }`}
            to="/login"
            onClick={() => handleMenuItemClick("Login")}
          >
            <p className="button is-outlined  is-danger">Mi Cuenta</p>
          </Link>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
