import Navbar from "/src/components/Navbar";
import Inicio from "./components/Inicio";
import Footer from "./components/Footer";
import Contacto from "./components/Contacto";
import Productos from "./components/Productlist";
import OneProducto from "./components/OneProduct";
import Nosotros from "./components/Nosotros";
import Login from "./components/Login";
import { BrowserRouter, Route, Routes } from "react-router-dom";

function App() {
  return (
    <>
      <BrowserRouter>
        <Navbar />

        <Routes>
          <Route path="/" element={<Inicio />} />
          <Route path="/productos" element={<Productos />} />
          <Route path="/productos/:id" element={<OneProducto />} />
          <Route path="/contacto" element={<Contacto />} />
          <Route path="/nosotros" element={<Nosotros />} />
          <Route path="/login" element={<Login />} />
        </Routes>

        <Footer />
      </BrowserRouter>
    </>
  );
}

export default App;
