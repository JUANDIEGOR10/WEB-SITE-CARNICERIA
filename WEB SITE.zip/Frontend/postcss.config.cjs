module.exports = {
    plugins: {
        autoprefixer: {}
    }
}