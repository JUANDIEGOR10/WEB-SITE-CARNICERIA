  import {
      validateFullName,
      validateEmail,
      validatePhone,
      validatePassword,
      validateComentario,
    } from "../hooks/useValidations";
  import { useState } from "react";
  import { Link } from "react-router-dom";
  import axios from 'axios';
  
  const ProveedorRegister = () => {
    const [formData, setFormData] = useState({
      nombreEmpresa: "",
      nitEmpresa: "",
      email: "",
      phone: "",
      direccion: "",
    });
  
    const [errors, setErrors] = useState({
      nombreEmpresa: "",
      nitEmpresa: "",
      email: "",
      phone: "",
      direccion: "",
    });

    const [showModal, setShowModal] = useState(false);
    const [modalContent, setModalContent] = useState("");
  
    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData({
        ...formData,
        [name]: value,
      });
  
      if (name === "nombreEmpresa") {
        const isValid = validateFullName(value);
        setErrors({
          ...errors,
          nombreEmpresa: isValid
            ? ""
            : "Nombre inválido. Solo se permiten letras, espacios y apóstrofes.",
        });
      }

      if (name === "nitEmpresa") {
        const isValid = validatePhone(value);
        setErrors({
          ...errors,
          nitEmpresa: isValid ? "" : "Nit no válido",
        });
      }
  
      if (name === "email") {
        const isValid = validateEmail(value);
        setErrors({
          ...errors,
          email: isValid ? "" : "Correo electrónico no válido",
        });
      }

      if (name === "phone") {
        const isValid = validatePhone(value);
        setErrors({
          ...errors,
          phone: isValid ? "" : "Número de contacto no válido",
        });
      }

      if (name === "direccion") {
        const isValid = validateComentario(value);
        setErrors({
          ...errors,
          direccion: isValid ? "" : "Dirección no es válida.",
        });
      }
    };
  
    const handleSubmit = async (e) => {
      e.preventDefault();
      const isNameValid = validateFullName(formData.nombreEmpresa);
      const isNitValid = validatePhone(formData.nitEmpresa);
      const isEmailValid = validateEmail(formData.email);
      const isPhoneValid = validatePhone(formData.phone);
      const isDireccionValid = validateComentario(formData.direccion);
    
      if (isNameValid && isNitValid && isEmailValid && isPhoneValid && isDireccionValid) {
        try {
          const response = await axios.post(import.meta.env.VITE_URI_BACK+ "/api/proveedor", formData);
          console.log("Entro!!")
          setModalContent("Proveedor registrado correctamente.");
          setShowModal(true);
        } catch (error) {
          if (error.response) {
            const errorMessage = error.response.data.msg || "Error desconocido";
            setModalContent(errorMessage);
            setShowModal(true);
          }
        }
      } else {
        setErrors({
          nombreEmpresa: isNameValid
            ? ""
            : "Nombre inválido. Solo se permiten letras, espacios y apóstrofes.",
          nitEmpresa: isNitValid ? "" : "Nit no válido.",
          email: isEmailValid ? "" : "Correo Electrónico no válido.",
          phone: isPhoneValid ? "" : "Número del Contacto no válido.",
          direccion: isDireccionValid ? "" : "Dirección no válida.",
        });
      }
    };
    
  
    return (
      <>
        <section class="section section-register">
          <div class="container container-background">
            <div class="columns is-centered">
              <div class="column is-6">
                <div class="box">
                  <h2 class="title is-2 has-text-centered mb-6 newh2">
                    Crear Proveedor
                  </h2>
                  <p class="subtitle is-6 has-text-centered mb-1 newsubtitle">
                    Por favor, complete los siguientes campos para crear el proveedor.
                  </p>
                  <form onSubmit={handleSubmit}>
                    <div class="field">
                      <label class="label">Nombre de la Empresa</label>
                      <div class="control">
                        <input
                          class="input"
                          id="nombreEmpresa"
                          name="nombreEmpresa"
                          type="text"
                          placeholder="Ingrese su nombre completo"
                          onChange={handleChange}
                        />
                      </div>
                      {errors.nombreEmpresa && (
                        <p className="help is-danger">{errors.nombreEmpresa}</p>
                      )}
                    </div>
                    <div class="field">
                      <label class="label">Nit</label>
                      <div class="control">
                        <input
                          class="input"
                          id="nitEmpresa"
                          name="nitEmpresa"
                          type="number"
                          placeholder="Ingrese su Nit"
                          onChange={handleChange}
                        />
                      </div>
                      {errors.nitEmpresa && (
                        <p className="help is-danger">{errors.nitEmpresa}</p>
                      )}
                    </div>
                    <div class="field">
                      <label class="label">Correo Electrónico</label>
                      <div class="control">
                        <input
                          class="input"
                          id="email"
                          name="email"
                          type="email"
                          placeholder="correo@example.com"
                          onChange={handleChange}
                        />
                      </div>
                      {errors.email && (
                        <p className="help is-danger">{errors.email}</p>
                      )}
                    </div>
                    <div class="field">
                      <label class="label">Número del Contacto</label>
                      <div class="control">
                        <input
                          class="input"
                          id="phone"
                          name="phone"
                          type="number"
                          placeholder="Ingrese su número de teléfono"
                          onChange={handleChange}
                        />
                      </div>
                      {errors.phone && (
                        <p className="help is-danger">{errors.phone}</p>
                      )}
                    </div>
                    <div class="field">
                      <label class="label">Dirección de la Empresa</label>
                      <div class="control">
                        <input
                          class="input"
                          id="direccion"
                          name="direccion"
                          type="text"
                          placeholder="Ingrese su número de teléfono"
                          onChange={handleChange}
                        />
                      </div>
                      {errors.direccion && (
                        <p className="help is-danger">{errors.direccion}</p>
                      )}
                    </div>
                    <div class="field is-grouped is-grouped-centered">
                      <div class="control">
                        <button class="button is-danger button-login">
                          Crear
                        </button>
                        <Link to="/administracion/proveedores" className="button is-link btn-form">
                            Regresar
                          </Link>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div className={`modal ${showModal ? "is-active" : ""}`}>
            <div className="modal-background" onClick={() => setShowModal(false)}></div>
            <div className="modal-card custom-modal">
              <header className="modal-card-head">
                <p className="modal-card-title">Mensaje</p>
                <Link className="delete" aria-label="close" to="/administracion/proveedores" onClick={() => setShowModal(false)}>
                </Link>
              </header>
              <section className="modal-card-body">
                <p>{modalContent}</p>
              </section>
            </div>
          </div>
        </section>
      </>
    );
  };
  
  export default ProveedorRegister;
  