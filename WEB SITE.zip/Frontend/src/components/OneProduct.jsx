import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from 'axios';

const OneProduct = () => {
  const [showModal, setShowModal] = useState(false);
  const [modalContent, setModalContent] = useState("");
  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`${import.meta.env.VITE_URI_BACK}/api/producto/${id}`);
        setShowModal(false);
        setProduct(response.data);
      } catch (error) {
        if (error.response) {
          const errorMessage = error.response.data.msg || "Error desconocido";
          setModalContent(errorMessage);
          setShowModal(true);
        }
      }
    };
    fetchData();
  }, [id]);

  if (!product) {
    return null;
  }

  const handleQuantityChange = (event) => {
    const newQuantity = parseInt(event.target.value);
    setQuantity(newQuantity);
  };

  const handleBuyNow = async () => {
    const userId = localStorage.getItem('userId');
    if (!userId) {
      setModalContent("Para realizar una compra, debes iniciar sesión.");
      setShowModal(true);
      return;
    }
    
    if (quantity > product.cantidad) {
      setModalContent("No hay suficiente producto en el inventario para realizar esta compra.");
      setShowModal(true);
      return;
    }
    
    try {
      const userId = localStorage.getItem('userId');
      const totalPrice = product.precio * quantity;
      const formData = {
        idProduct: product._id,
        idUser: userId,
        nameProduct: product.nombre,
        cantidad: quantity,
        precioTotal: totalPrice,
        estado: "Pagado"
      };

      const response = await axios.post(`${import.meta.env.VITE_URI_BACK}/api/venta`, formData);
      setModalContent("Compra registrada correctamente.");
      setShowModal(true);
    } catch (error) {
      console.error('Error al realizar la compra:', error);
      setModalContent(error);
      setShowModal(true);
    }
  };

  return (
    <section className="oneproduct">
      <div className="columns productopromo">
        <div className="column is-6 columnimagen">
          <div className="image-product">
            <div className="centered-image">
              <img src={product.imagen} alt="" className="is-4 product-image" />
            </div>
          </div>
        </div>
        <div className="column has-background-black columnpromo containerdescrip">
          <div className="container-promo has-text-centered">
            <h2 className="title is-1 newh2">{product.nombre}</h2>
            <p className="has-text-white">{product.descripcion}</p>
            {product.cantidad > 0 && (
              <div>
                <div className="div-cantidad field is-horizontal">
                  <div className="field-label is-normal">
                    <label className="label has-text-white">Cantidad:</label>
                  </div>
                  <div className="field-body">
                    <div className="field">
                      <div className="control">
                        <input
                          className="input"
                          type="number"
                          min="1"
                          value={quantity}
                          onChange={handleQuantityChange}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <p className="p-precio has-text-white">${(product.precio)*quantity} COP</p>
                <div className="boton-productos">
                  <button className="button is-outlined is-info btncomprar" onClick={handleBuyNow}>
                    Comprar ahora
                  </button>
                </div>
              </div>
            )}
            {product.cantidad === 0 && (
              <p className="title p-agotado">Agotado</p>
            )}
          </div>
        </div>
      </div>
      <div className={`modal ${showModal ? "is-active" : ""}`}>
        <div className="modal-background" onClick={() => setShowModal(false)}></div>
        <div className="modal-card custom-modal">
          <header className="modal-card-head">
            <p className="modal-card-title">Mensaje</p>
            <Link to="/tienda" className="delete" aria-label="close" onClick={() => setShowModal(false)}>
            </Link>
          </header>
          <section className="modal-card-body">
            <p>{modalContent}</p>
          </section>
        </div>
      </div>
    </section>
  );
};

export default OneProduct;
