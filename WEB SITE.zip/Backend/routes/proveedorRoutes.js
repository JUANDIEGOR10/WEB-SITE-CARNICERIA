import express from "express"
import {
    registrarProveedor, 
    mostrarProveedor, 
    deleteProveedor, 
    editProveedor,
    mostrarOneProveedor,
} from "../controller/proveedorController.js"
const router = express.Router()

router.get('/',mostrarProveedor)
router.get('/:id', mostrarOneProveedor)
router.post('/',registrarProveedor)
router.delete('/:id', deleteProveedor)
router.put("/:id", editProveedor)

// router.get("/",(req,res)=>{
//     res.json("Peticion Get Desde API/Usuario")
//     //json para envio de datos y send para enviar mensajes
// });

export default router;