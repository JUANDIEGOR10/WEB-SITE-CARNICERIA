import Venta from "../model/Venta.js"
import Producto from "../model/Producto.js";

const registrarVenta = async (req, res) => {
    try {
        const venta = new Venta(req.body);
        const producto = await Producto.findById(venta.idProduct);
        
        if (!producto) {
            throw new Error("El producto no existe.");
        }
        
        if (producto.cantidad < venta.cantidad) {
            return res.status(400).json({ msg: "No hay suficiente cantidad en el inventario." });
        }
        
        producto.cantidad -= venta.cantidad;
        await producto.save();
        const ventaAlmacenado = await venta.save();
        res.json(ventaAlmacenado);
    } catch (error) {
        console.log(error);
        res.status(500).json({ msg: "Error al registrar la venta." });
    }
}

const mostrarVenta = async(req, res) => {
    try {
        const venta = await Venta.find()
        res.json(venta)
    } catch (error) {
        console.log(error)
    }
}

const mostrarOneVenta = async (req, res) => {
    const { id } = req.params;

    try {
        const venta = await Venta.findOne({ _id: id });
        if (!venta) {
            throw new Error("La venta no existe.");
        }
        res.json(venta);
    } catch (error) {
        console.log(error);
        return res.status(400).json({ msg: error.message });
    }
}

const mostrarVentasbyUserId = async (req, res) => {
    const { userId } = req.params;

    try {
        const ventasUsuario = await Venta.find({ idUser: userId });
        
        if (ventasUsuario.length === 0) {
            return res.status(404).json({ msg: "No se encontraron ventas para este usuario." });
        }

        res.json(ventasUsuario);
    } catch (error) {
        console.log(error);
        return res.status(500).json({ msg: "Error al buscar ventas para este usuario." });
    }
}

const editVenta = async (req, res) =>{
    const { id } = req.params;
    const newData = req.body;

    try {
        const venta = await Venta.findOneAndUpdate({ _id: id }, { $set: newData }, { new: true });
        if (!venta) {
        throw new Error("La venta no existe.");
        }
        res.json({ message: "Venta actualizada exitosamente", venta });
    } catch (error) {
        console.log(error);
        return res.status(400).json({ msg: error.message });
    }
}

export {registrarVenta, mostrarVenta, mostrarOneVenta, mostrarVentasbyUserId, editVenta}