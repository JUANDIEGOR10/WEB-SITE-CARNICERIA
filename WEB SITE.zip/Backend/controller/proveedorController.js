import Proveedor from "../model/Proveedor.js"

const registrarProveedor = async(req, res) => {
    try {
        const proveedor = new Proveedor(req.body)
        const proveedorAlmacenado= await proveedor.save()
        res.json(proveedorAlmacenado)
    } catch (error) {
        console.log(error)
    }
}

const mostrarProveedor = async(req, res) => {
    try {
        const proveedor = await Proveedor.find()
        res.json(proveedor)
    } catch (error) {
        console.log(error)
    }
}

const mostrarOneProveedor = async (req, res) => {
    const { id } = req.params;

    try {
        const proveedor = await Proveedor.findOne({ _id: id });
        if (!proveedor) {
            throw new Error("El Proveedor no existe.");
        }
        res.json(proveedor);
    } catch (error) {
        console.log(error);
        return res.status(400).json({ msg: error.message });
    }
}

const deleteProveedor = async (req, res) => {
    const { id } = req.params;
    try {
        const proveedorEliminado = await Proveedor.findByIdAndDelete(id);
        if (!proveedorEliminado) {
            throw new Error("El proveedor no existe.");
        }
        res.json({ message: "Proveedor eliminado exitosamente" });
    } catch (error) {
        console.log(error);
        return res.status(400).json({ msg: error.message });
    }
}

const editProveedor = async (req, res) =>{
    const { id } = req.params;
    const newData = req.body;

    try {
        const proveedor = await Proveedor.findOneAndUpdate({ _id: id }, { $set: newData }, { new: true });
        if (!proveedor) {
        throw new Error("El proveedor no existe.");
        }
        res.json({ message: "Proveedor actualizado exitosamente", proveedor });
    } catch (error) {
        console.log(error);
        return res.status(400).json({ msg: error.message });
    }
}

export {registrarProveedor, mostrarProveedor, mostrarOneProveedor, deleteProveedor, editProveedor}