import mongoose, { mongo } from "mongoose";

const userSchema = mongoose.Schema(
    {
        nombreEmpresa:{
            type: String,
            required:true,
            trie:true
        },
        nitEmpresa:{
            type: Number,
            required:true,
            trie:true,
            unique:true
        },
        email:{
            type: String,
            required:true,
            trie:true
        },
        phone:{
            type: Number,
            required:true,
            trie:true,
        },
        direccion:{
            type: String,
            required:true,
            trie:true
        },
    },
    {
        timestamps:true,
    }
)

const proveedor = mongoose.model("Proveedor",userSchema)
export default proveedor;